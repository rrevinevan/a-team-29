README

Course: cs400
Semester: Fall 2019
Project name: Team Project -- Milk Weight
Team Members: (ateam 29)
1. Andrew Meyers, 002, and ajmeyers4@wisc.edu
2. Evan Grubis, 002, and egrubis@wisc.edu

 
Which team members were on same xteam together?
None

Other notes or comments to the grader:
None
